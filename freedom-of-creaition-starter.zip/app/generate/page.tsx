'use client'

// app/generate/page.tsx
export const dynamic = 'force-dynamic'; // This prevents static prerendering

import { useState, useEffect } from 'react';
import { getSupabase } from '@/lib/supabase';

export default function GeneratePage() {
  const [prompt, setPrompt] = useState('');
  const [images, setImages] = useState([]);
  const [imageFiles, setImageFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [nsfwMode, setNsfwMode] = useState(false);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleGenerate = async () => {
    if (!isClient) return;

    setLoading(true);
    const formData = new FormData();
    formData.append('prompt', prompt);
    formData.append('nsfw', nsfwMode);
    imageFiles.forEach(file => formData.append('image', file));

    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/generate`, {
      method: 'POST',
      body: formData,
    });

    const data = await res.json();
    setImages(data.images);
    setLoading(false);
  };

  return (
    <div className="p-8 max-w-4xl mx-auto text-white bg-black min-h-screen">
      <h1 className="text-3xl font-bold mb-6">Generate Your Image</h1>

      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        placeholder="Describe your scene or idea..."
        className="w-full p-4 mb-4 bg-gray-900 border border-gray-700 rounded-md"
      />

      <input
        type="file"
        accept="image/*"
        multiple
        onChange={(e) => setImageFiles(Array.from(e.target.files))}
        className="mb-4 text-white"
      />

      <label className="flex items-center mb-4">
        <input
          type="checkbox"
          checked={nsfwMode}
          onChange={() => setNsfwMode(!nsfwMode)}
          className="mr-2"
        />
        Enable NSFW Mode
      </label>

      <button
        onClick={handleGenerate}
        disabled={loading || !prompt}
        className="bg-blue-600 hover:bg-blue-700 px-6 py-2 rounded-md"
      >
        {loading ? 'Generating...' : 'Generate'}
      </button>

      <div className="grid grid-cols-2 gap-4 mt-8">
        {images.map((img, index) => (
          <img
            key={index}
            src={`data:image/png;base64,${img}`}
            alt="Generated Result"
            className="w-full rounded-lg border border-gray-800"
          />
        ))}
      </div>
    </div>
  );
}
